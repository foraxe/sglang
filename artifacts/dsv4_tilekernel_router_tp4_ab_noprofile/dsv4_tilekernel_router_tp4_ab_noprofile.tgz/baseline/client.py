import json, sys, time, urllib.request
port=int(sys.argv[1]); out=sys.argv[2]
payload={"input_ids": list(range(1,4097)), "sampling_params":{"max_new_tokens":2,"temperature":0}}
def post(path, body, timeout=1200):
    req=urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=json.dumps(body).encode(), headers={"Content-Type":"application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r: return r.status, r.read().decode()
for _ in range(900):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/model_info", timeout=2) as r:
            if r.status==200: break
    except Exception: time.sleep(1)
else: raise SystemExit("server not ready")
try: post('/flush_cache', {}, timeout=120)
except Exception as e: open(out+'.flush_error','w').write(repr(e))
t=time.time(); status, body=post('/generate', payload); elapsed=time.time()-t
open(out,'w').write(json.dumps({"status":status,"elapsed":elapsed,"body":json.loads(body)}, indent=2))
