import json
import os
import sys
import time
import urllib.request

port = int(sys.argv[1])
out = sys.argv[2]
profile = os.environ.get("PROFILE", "0") == "1"
payload = {
    "input_ids": list(range(1, 4097)),
    "sampling_params": {"max_new_tokens": 2, "temperature": 0},
}

def post(path, body, timeout=1200):
    req = urllib.request.Request(
        f"http://127.0.0.1:{port}{path}",
        data=json.dumps(body).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status, resp.read().decode()

for _ in range(900):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/model_info", timeout=2) as resp:
            if resp.status == 200:
                break
    except Exception:
        time.sleep(1)
else:
    raise SystemExit("server not ready")

if profile:
    post("/start_profile", {
        "activities": ["CPU", "GPU"],
        "with_stack": True,
        "record_shapes": True,
        "profile_prefix": os.path.basename(os.path.dirname(out)),
    })

t0 = time.time()
status, body = post("/generate", payload)
elapsed = time.time() - t0

if profile:
    post("/stop_profile", {})

with open(out, "w") as f:
    json.dump({"status": status, "elapsed": elapsed, "body": json.loads(body)}, f, indent=2)
